import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/destination.dart';

class DestinationService {
  final CollectionReference destinationCollection =
      FirebaseFirestore.instance.collection('destinations');

  Stream<List<Destination>> get destinations {
    return destinationCollection.snapshots().map(_destinationListFromSnapshot);
  }

  List<Destination> _destinationListFromSnapshot(QuerySnapshot snapshot) {
    return snapshot.docs.map((doc) {
      return Destination(
        id: doc.id,
        name: doc['name'] ?? '',
        description: doc['description'] ?? '',
        imageUrl: doc['imageUrl'] ?? '',
        price: doc['price'] ?? 0.0,
      );
    }).toList();
  }

  Future<void> addDestination(Destination destination) async {
    await destinationCollection.add({
      'name': destination.name,
      'description': destination.description,
      'imageUrl': destination.imageUrl,
      'price': destination.price,
    });
  }
}
